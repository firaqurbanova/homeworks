// import React from "react";
// function Homework() {
//   return (
//       <div>
//             <button>Open first modal</button>
//             <button>Open second modal</button>
//       </div>
//   );
// }
// export default Homework;